<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id10709442_iwan","12345","id10709442_remidi") or die ("could not connect database");
?>
